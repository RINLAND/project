package com.setup.test2.Model;

public class ComCalVO {
	private int comcal_id;
	private String comstartDate;
	private String comendDate;
	private String comcalContent;
	
	
	
	public int getComcal_id() {
		return comcal_id;
	}
	public void setComcal_id(int comcal_id) {
		this.comcal_id = comcal_id;
	}
	public String getComstartDate() {
		return comstartDate;
	}
	public void setComstartDate(String comstartDate) {
		this.comstartDate = comstartDate;
	}
	public String getComendDate() {
		return comendDate;
	}
	public void setComendDate(String comendDate) {
		this.comendDate = comendDate;
	}
	public String getComcalContent() {
		return comcalContent;
	}
	public void setComcalContent(String comcalContent) {
		this.comcalContent = comcalContent;
	}
	
	
}
