package com.setup.test2.Model;

public class SysVO {

	private String sysLogo;
	private String sysTitle;
	private String sysSub;
	private String sysCeo;
	private String sysAddr;
	private String sysCopy;
	private String sysUrl;
	private int sysAuth;
	private String sysUp;
	private String sysDown;
	private String sysTell;
	
	public String getSysLogo() {
		return sysLogo;
	}
	public void setSysLogo(String sysLogo) {
		this.sysLogo = sysLogo;
	}
	public String getSysTitle() {
		return sysTitle;
	}
	public void setSysTitle(String sysTitle) {
		this.sysTitle = sysTitle;
	}
	public String getSysSub() {
		return sysSub;
	}
	public void setSysSub(String sysSub) {
		this.sysSub = sysSub;
	}
	public String getSysCeo() {
		return sysCeo;
	}
	public void setSysCeo(String sysCeo) {
		this.sysCeo = sysCeo;
	}
	public String getSysAddr() {
		return sysAddr;
	}
	public void setSysAddr(String sysAddr) {
		this.sysAddr = sysAddr;
	}
	public String getSysCopy() {
		return sysCopy;
	}
	public void setSysCopy(String sysCopy) {
		this.sysCopy = sysCopy;
	}
	public String getSysUrl() {
		return sysUrl;
	}
	public void setSysUrl(String sysUrl) {
		this.sysUrl = sysUrl;
	}
	public int getSysAuth() {
		return sysAuth;
	}
	public void setSysAuth(int sysAuth) {
		this.sysAuth = sysAuth;
	}
	public String getSysUp() {
		return sysUp;
	}
	public void setSysUp(String sysUp) {
		this.sysUp = sysUp;
	}
	public String getSysDown() {
		return sysDown;
	}
	public void setSysDown(String sysDown) {
		this.sysDown = sysDown;
	}
	public String getSysTell() {
		return sysTell;
	}
	public void setSysTell(String sysTell) {
		this.sysTell = sysTell;
	}
	
	
	
	
	
}
