package com.setup.test2.Model;

import java.util.Date;

public class BoardVO {
	private int boardID;
	private String boardTeam;
	private String boardCode;
	private String boardColor;
	private String boardMaker;
	private String boardTitle;
	private String boardType;
	private String boardRead;
	private String boardWrite;
	private String boardReply;
	private String boardDown;
	private Date boardRegdate;
	private String team_name;
	private String boardReference;
	private String boardDetail;
	
	
	public int getBoardID() {
		return boardID;
	}
	public void setBoardID(int boardID) {
		this.boardID = boardID;
	}
	public String getBoardTeam() {
		return boardTeam;
	}
	public void setBoardTeam(String boardTeam) {
		this.boardTeam = boardTeam;
	}
	public String getBoardCode() {
		return boardCode;
	}
	public void setBoardCode(String boardCode) {
		this.boardCode = boardCode;
	}
	public String getBoardColor() {
		return boardColor;
	}
	public void setBoardColor(String boardColor) {
		this.boardColor = boardColor;
	}
	public String getBoardMaker() {
		return boardMaker;
	}
	public void setBoardMaker(String boardMaker) {
		this.boardMaker = boardMaker;
	}
	public String getBoardTitle() {
		return boardTitle;
	}
	public void setBoardTitle(String boardTitle) {
		this.boardTitle = boardTitle;
	}
	public String getBoardType() {
		return boardType;
	}
	public void setBoardType(String boardType) {
		this.boardType = boardType;
	}
	public String getBoardRead() {
		return boardRead;
	}
	public void setBoardRead(String boardRead) {
		this.boardRead = boardRead;
	}
	public String getBoardWrite() {
		return boardWrite;
	}
	public void setBoardWrite(String boardWrite) {
		this.boardWrite = boardWrite;
	}
	public String getBoardReply() {
		return boardReply;
	}
	public void setBoardReply(String boardReply) {
		this.boardReply = boardReply;
	}
	public String getBoardDown() {
		return boardDown;
	}
	public void setBoardDown(String boardDown) {
		this.boardDown = boardDown;
	}
	public Date getBoardRegdate() {
		return boardRegdate;
	}
	public void setBoardRegdate(Date boardRegdate) {
		this.boardRegdate = boardRegdate;
	}
	public String getTeam_name() {
		return team_name;
	}
	public void setTeam_name(String team_name) {
		this.team_name = team_name;
	}
	public String getBoardReference() {
		return boardReference;
	}
	public void setBoardReference(String boardReference) {
		this.boardReference = boardReference;
	}
	public String getBoardDetail() {
		return boardDetail;
	}
	public void setBoardDetail(String boardDetail) {
		this.boardDetail = boardDetail;
	}
	
	

}
