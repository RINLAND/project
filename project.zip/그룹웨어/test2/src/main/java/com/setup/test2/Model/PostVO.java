package com.setup.test2.Model;

public class PostVO {
	
	public String post_name;
	public String post_id;
	
	
	public String getPost_name() {
		return post_name;
	}
	public void setPost_name(String post_name) {
		this.post_name = post_name;
	}
	public String getPost_id() {
		return post_id;
	}
	public void setPost_id(String post_id) {
		this.post_id = post_id;
	}
	
	

}
